package client;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;

public class Number {
	public char[] str;
	public int x;
	public int y;
	
	public int size = 5;
	
	public Number(String str,int x,int y,int size){
		this.str = str.toCharArray();
		this.x = x;
		this.y = y;
		this.size = size;
	}
	
	//����
	public Number(int size,String str,int width,int y){
		int total=0;
		for(int i=0;i<str.length();i++){
			total += size*4;
		}
		total-=size;
		this.str = str.toCharArray();
		this.x = (width-total)/2;
		this.y=y;
		this.size = size;
	}
	
	public Shape[] getShapes(){
		Shape[] shapes = new Shape[str.length];
		for(int i=0;i<str.length;i++){
			shapes[i] = new Rectangle(x+i*size*4,y,size*3,size*5);
		}
		
		return shapes;
	}
	
	public void draw(Graphics2D g2d){
		
		for(int i=0;i<str.length;i++){
			if(str[i]==' '){
				continue;
			}
			if(str[i]==':'){
				g2d.fillRect(x+i*size*4+size,y,size,size);
				g2d.fillRect(x+i*size*4+size,y+size*4,size,size);
				continue;
			}
			if(str[i]=='.'){
				g2d.fillRect(x+i*size*4+size,y+size*4,size,size);
				continue;
			}
			drawInt(g2d,x+i*size*4,y,new Integer(str[i]+""));
		}
		
	}
	
	private void drawInt(Graphics2D g2d,int x,int y,int num){
		switch(num){
			case 0:
				g2d.fillRect(x, y, size, size*5);
				g2d.fillRect(x+size*2, y, size, size*5);
				g2d.fillRect(x+size,y,size,size);
				g2d.fillRect(x+size,y+size*4,size,size);
				break;
			case 1:
				g2d.fillRect(x+size*2, y, size, size*5);
				break;
			case 2:
				g2d.fillRect(x, y, size*3, size);
				g2d.fillRect(x, y+size*2, size*3, size);
				g2d.fillRect(x, y+size*4, size*3, size);
				g2d.fillRect(x+size*2,y+size,size,size);
				g2d.fillRect(x,y+size*3,size,size);
				break;
			case 3:
				g2d.fillRect(x, y, size*3, size);
				g2d.fillRect(x, y+size*2, size*3, size);
				g2d.fillRect(x, y+size*4, size*3, size);
				g2d.fillRect(x+size*2,y+size,size,size);
				g2d.fillRect(x+size*2,y+size*3,size,size);
				break;
			case 4:
				g2d.fillRect(x+size*2, y, size, size*5);
				g2d.fillRect(x, y, size, size*3);
				g2d.fillRect(x+size, y+size*2, size, size);
				break;
			case 5:
				g2d.fillRect(x, y, size*3, size);
				g2d.fillRect(x, y+size*2, size*3, size);
				g2d.fillRect(x, y+size*4, size*3, size);
				g2d.fillRect(x,y+size,size,size);
				g2d.fillRect(x+size*2,y+size*3,size,size);
				break;
			case 6:
				g2d.fillRect(x, y, size, size*5);
				g2d.fillRect(x+size*2, y+size*2, size, size*3);
				g2d.fillRect(x+size,y,size*2,size);
				g2d.fillRect(x+size,y+size*2,size,size);
				g2d.fillRect(x+size,y+size*4,size,size);
				break;
			case 7:
				g2d.fillRect(x+size*2, y, size, size*5);
				g2d.fillRect(x, y, size*2, size);
				break;
			case 8:
				g2d.fillRect(x, y, size*3, size);
				g2d.fillRect(x, y+size*2, size*3, size);
				g2d.fillRect(x, y+size*4, size*3, size);
				g2d.fillRect(x,y+size,size,size);
				g2d.fillRect(x+size*2,y+size*3,size,size);
				g2d.fillRect(x+size*2,y+size,size,size);
				g2d.fillRect(x,y+size*3,size,size);
				break;
			case 9:
				g2d.fillRect(x+size*2, y, size, size*5);
				g2d.fillRect(x, y, size, size*3);
				g2d.fillRect(x+size, y, size, size);
				g2d.fillRect(x+size, y+size*2, size, size);
				g2d.fillRect(x, y+size*4, size*2, size);
				break;
		}
	}
	
}
