package client;

import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.Icon;

import liren.mp.component.MPButton;

public class Icons {
	
	public static Icon getOptionsIcon(MPButton b) {
		return new Icon() {
			private int width = getIconWidth();
			private int height = getIconHeight();
			
			@Override
			public void paintIcon(Component c, Graphics g, int x, int y) {
				g.setColor(Main.lanucher.style.foreground);
				Graphics2D g2d = b.getShape().createGraphics2D(g);
				
				g2d.drawLine(width*30/100, height*25/100, width*80/100, height*25/100);
				g2d.drawLine(width*30/100, height*50/100, width*80/100, height*50/100);
				g2d.drawLine(width*30/100, height*75/100, width*80/100, height*75/100);
				
				g2d.setStroke(new BasicStroke(2.5f));
				g2d.drawLine(width*20/100, height*25/100, width*20/100, height*25/100);
				g2d.drawLine(width*20/100, height*50/100, width*20/100, height*50/100);
				g2d.drawLine(width*20/100, height*75/100, width*20/100, height*75/100);
			}

			@Override
			public int getIconWidth() {
				return b.getWidth();
			}

			@Override
			public int getIconHeight() {
				return b.getHeight();
			}
			
		};
	}
	
	public static Icon getFunctionIcon(MPButton b) {
		return new Icon() {
			private int width = getIconWidth();
			private int height = getIconHeight();
			
			@Override
			public void paintIcon(Component c, Graphics g, int x, int y) {
				g.setColor(Main.lanucher.style.foreground);
				Graphics2D g2d = b.getShape().createGraphics2D(g);
				g2d.setStroke(new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
				
				g2d.drawRect(width*20/100, height*20/100, width*64/100, height*64/100);
				g2d.drawLine(width*20/100, height*50/100, width*79/100, height*50/100);
				g2d.drawLine(width*50/100, height*20/100, width*50/100, height*79/100);
				g2d.drawLine(width*21/100, height*79/100, width*79/100, height*21/100);
				
				g2d.drawLine(width*50/100, height*20/100, width*45/100, height*25/100);
				g2d.drawLine(width*50/100, height*20/100, width*55/100, height*25/100);
				
				g2d.drawLine(width*80/100, height*50/100, width*75/100, height*45/100);
				g2d.drawLine(width*80/100, height*50/100, width*75/100, height*55/100);
			}

			@Override
			public int getIconWidth() {
				return b.getWidth();
			}

			@Override
			public int getIconHeight() {
				return b.getHeight();
			}
			
		};
	}
	
}
