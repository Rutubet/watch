package client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Options implements Serializable{
	private static final long serialVersionUID = 2680657581564552369L;
	
	private boolean isAlwaysOnTop;
	public boolean is24HourClock,isPaintNTBackground;
	
	public int frameX,frameY;
	
	private static File file = new File("options.ser");
	
	public Options() {
		this.setIsAlwaysOnTop(true);
		this.is24HourClock=false;
		this.isPaintNTBackground=true;
		this.setFrameLocation();
	}
	
	public boolean getIsAlwayOnTop() {
		return isAlwaysOnTop;
	}
	
	public boolean saveToLocal() {
		setFrameLocation();
		try {
			
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
			oos.writeObject(this);
			oos.close();
			return true;
			
		} catch (IOException e) {
			return false;
		}
	}
	
	private void setFrameLocation() {
		this.frameX=Main.lanucher.frame.getX();
		this.frameY=Main.lanucher.frame.getY();
	}
	
	public void setIsAlwaysOnTop(boolean b) {
		this.isAlwaysOnTop=b;
		Main.lanucher.frame.setAlwaysOnTop(isAlwaysOnTop);
	}
	
	public static boolean loadByLocal() {
		try {
			
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
			Main.lanucher.options = (Options)ois.readObject();
			Main.lanucher.options.setIsAlwaysOnTop(Main.lanucher.options.isAlwaysOnTop);
			ois.close();
			return true;
			
		} catch (IOException e) {
			return false;
		} catch (ClassNotFoundException e) {
			return false;
		}
	}

}
