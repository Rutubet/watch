package client.ui.panel;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.Timer;

import client.Main;
import liren.mp.lightcomponent.NixieTube;
import liren.mp.lightcomponent.Panel;
import liren.mp.lightcomponent.layout.LinerLayout;

public class TimePanel extends Panel{
	private static final int LOWER_LIMIT=0,UPPER_LIMIT=1;
	public static final int TIME_MODE=0,TIMING_MODE=1;
	
	private String colonStr; //ð���涯���������ı������Ӧ��ֵ
	private Timer colonTimer; //ð��Timer
	private int mode;
	private Instant startTime,endTime;
	private boolean shouldTiming,isTiming;
	private LocalDateTime dateTime;
	
	private NixieTube hourMinNT,secondWeekNT,monthDayNT;
	
	public TimePanel(int x, int y, int width, int height) {
		super(x, y, width, height);
		this.setColor(Main.lanucher.style.foreground);
		this.colonStr=" ";
		this.mode=TIME_MODE;
		this.startTime=null;
		this.endTime=null;
		this.shouldTiming=false;
		this.isTiming=false;
		//����ð�ŵĶ���
		colonTimer = new Timer(500,new ActionListener(){
			private boolean isDrawColon;//�Ƿ����ð��
			
			@Override
			public void actionPerformed(ActionEvent e) {
				isDrawColon=!isDrawColon;
				if(isDrawColon){
					colonStr=":";
				}else{
					colonStr=" ";
				}
			}
			
		});
		colonTimer.setRepeats(true);
		colonTimer.start();
		//���������
		this.hourMinNT = new NixieTube(5,6);
		this.secondWeekNT = new NixieTube(4,4);
		this.monthDayNT = new NixieTube(5,5);
		//���������ֹ��������������
		LinerLayout ll = new LinerLayout(this.getWidth(),this.getHeight(),LinerLayout.UP_TO_DOWN,50,10);
		ll.add(hourMinNT);
		ll.add(secondWeekNT);
		ll.add(monthDayNT);
		this.add(hourMinNT);
		this.add(secondWeekNT);
		this.add(monthDayNT);
	}
	
	@Override
	public String toString() {
		return dateTime.toString();
	}
	
	public void lowerPage() {
		if(mode>LOWER_LIMIT) {
			mode--;
		}
	}
	
	public void upperPage() {
		if(mode<UPPER_LIMIT) {
			mode++;
		}
	}
	
	public void setMode(int mode) {
		this.mode=mode;
	}
	
	public int getMode() {
		return this.mode;
	}
	
	public void startTiming() {
		shouldTiming=true;
		isTiming=true;
	}
	
	public void stopTiming() {
		endTime=Instant.now();
		isTiming=false;
	}
	
	public void clearTiming() {
		isTiming=false;
		shouldTiming=false;
		startTime=null;
		endTime=null;
	}
	
	public boolean isTiming() {
		return isTiming;
	}
	
	public boolean isEnding() {
		return endTime!=null;
	}
	
	@Override
	public void paint(Graphics gg) {
		super.paint(gg);
	}

	@Override
	public void paintComponents(Graphics g) {
		super.paintComponents(g);
	}

	@Override
	public void paintChildren(Graphics g) {
		if(mode==TIME_MODE) {
			paintTime(g);
		}else if(mode==TIMING_MODE) {
			paintTiming(g);
		}
		
		
	}
	
	public void paintTime(Graphics g) {
		dateTime = LocalDateTime.now();
		paintDateTime(g,dateTime);
	}
	
	public void paintTiming(Graphics g) {
		Instant timing;
		if(endTime==null) {
			timing=Instant.now();
		}else {
			timing=endTime;
		}
		
		if(startTime==null) {
			startTime=timing;
		}else if(!shouldTiming) {
			startTime=timing;
		}
		
		if(!shouldTiming) {
			timing=startTime;
		}
		
		Duration duration = Duration.between(startTime, timing);
		
		String hour = String.format("%02d", duration.toHours()%24);
		String minute = String.format("%02d", duration.toMinutes()%60);
		String second = String.format("%02d", duration.getSeconds()%60);
		String millis = String.format("%03d", duration.toMillis()%1000);
		
		hourMinNT.setString(hour+colonStr+minute);
		secondWeekNT.setString(" "+second+" ");
		monthDayNT.setString(" "+millis+" ");
		
		hourMinNT.setForeground(g.getColor());
		secondWeekNT.setForeground(g.getColor());
		monthDayNT.setForeground(g.getColor());
		
		super.paintChildren(g);
		
	}
	
	public void paintDateTime(Graphics g,LocalDateTime dateTime) {
		String month = dateTime.format(DateTimeFormatter.ofPattern("MM"));
		String day = dateTime.format(DateTimeFormatter.ofPattern("dd"));
		String hour12 = dateTime.format(DateTimeFormatter.ofPattern("hh"));
		String hour24 = dateTime.format(DateTimeFormatter.ofPattern("HH"));
		String minute = dateTime.format(DateTimeFormatter.ofPattern("mm"));
		String second = dateTime.format(DateTimeFormatter.ofPattern("ss"));
		String amorpm=" ";
		int hourValue = dateTime.getHour();
		int weekValue = dateTime.getDayOfWeek().getValue();
		if(hourValue<12) {
			amorpm="A";
		}else {
			amorpm="P";
		}
		
		if(Main.lanucher.options.isPaintNTBackground) {
			hourMinNT.setString("88 88");
			secondWeekNT.setString("88  ");
			monthDayNT.setString("88 88");
			
			int alpha = 25;
			hourMinNT.setForeground(Main.lanucher.style.getForegroundByAlpha(alpha));
			secondWeekNT.setForeground(Main.lanucher.style.getForegroundByAlpha(alpha));
			monthDayNT.setForeground(Main.lanucher.style.getForegroundByAlpha(alpha));
			super.paintChildren(g);
		}
		
		if(Main.lanucher.options.is24HourClock) {
			hourMinNT.setString(hour24+colonStr+minute);
			amorpm=" ";
		}else {
			hourMinNT.setString(hour12+colonStr+minute);
		}
		
		secondWeekNT.setString(second+amorpm);
		secondWeekNT.setDataBit(weekValue, 3);
		monthDayNT.setString(month+"."+day);
		
		hourMinNT.setForeground(g.getColor());
		secondWeekNT.setForeground(g.getColor());
		monthDayNT.setForeground(g.getColor());
		
		super.paintChildren(g);
	}
	
}
