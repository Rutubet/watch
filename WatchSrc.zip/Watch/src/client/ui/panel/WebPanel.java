package client.ui.panel;

import java.awt.Graphics;

import liren.mp.lightcomponent.Panel;

public class WebPanel extends Panel{

	public WebPanel(int x, int y, int width, int height) {
		super(x, y, width, height);
	}
	
	@Override
	public void paint(Graphics gg) {
		// TODO Auto-generated method stub
		super.paint(gg);
	}

}
