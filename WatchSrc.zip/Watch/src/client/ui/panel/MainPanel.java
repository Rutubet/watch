package client.ui.panel;

import java.awt.Graphics;

import client.Main;
import liren.mp.lightcomponent.Panel;

public class MainPanel extends Panel{
	private int dx,dy;
	public TimePanel timePanel;
	private WebPanel webPanel;
	
	public MainPanel(int x, int y, int width, int height) {
		super(x, y, width, height);
		this.dx=-130;
		this.dy=0;
		//������ʾʱ���Panel
		timePanel=new TimePanel(130,0,130,130);
		this.add(timePanel);
		//���ú���ҳ��ص�Panel
		webPanel=new WebPanel(0,0,130,130);
		webPanel.setColor(Main.lanucher.style.foreground);
		this.add(webPanel);
	}
	
	public void setDelta(int dx,int dy) {
		this.dx=dx;
		this.dy=dy;
	}
	
	public int getDeltaX() {
		return dx;
	}
	
	public int getDeltaY() {
		return dy;
	}
	
	@Override
	public void paintComponents(Graphics g) {
		super.paintComponents(g);
	}
	
	@Override
	public void paintChildren(Graphics g) {
		Graphics gg = g.create(dx, dy, width*lcs.size(), height);
		gg.setColor(this.foreground);
		super.paintChildren(gg);
	}
	
}
