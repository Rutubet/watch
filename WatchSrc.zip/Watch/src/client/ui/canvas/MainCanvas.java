package client.ui.canvas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.event.MouseInputListener;

import client.Main;
import client.ui.panel.MainPanel;
import client.ui.panel.TimePanel;

import liren.cap.animation.Animation;
import liren.jar.Jar;
import liren.mp.component.MPButton;
import liren.mp.lightcomponent.layout.LinerLayout;
import liren.mp.style.MPShape;
import updater.WatchUpdater;

@SuppressWarnings("serial")
public class MainCanvas extends JPanel{
	private MPShape shape; //��������״
	private MainPanel mainPanel;
	private Timer colorTimer;  //��ɫ�仯Timer
	private Color numberColor; //���ֵ���ɫ
	
	private WatchUpdater watchUpdater;
	private boolean shouldShowUpdater;
	private int clipHeight; //��ʼʱ����չ���������Ƶ�clip�ĸ�
	private Animation spreadAni; //��ʼʱ����չ���Ķ���
	private Animation btnAni; //��ʼʱ��ť����Ķ���
	
	public MainCanvas(){
		//����һЩ��ʼֵ
		super();
		this.setBounds(300,0,200,200);
		this.shouldShowUpdater=true;
		this.numberColor=Main.lanucher.style.foreground;
		this.setBackground(Main.lanucher.style.background);
		this.setForeground(Main.lanucher.style.foreground);
		this.setLayout(null);
		this.setFocusable(true);
		this.requestFocusInWindow();
		this.enableInputMethods(false);
		//������ɫ����Ķ���
		colorTimer = new Timer(50,new ActionListener(){
			private int minValue=200;//��С͸����ֵ
			private int maxValue=250;//���͸����ֵ
			private int alpha=maxValue;//͸����ֵ
			
			private boolean shouldAddSelf;//�Ƿ��Լ�
			
			@Override
			public void actionPerformed(ActionEvent e) {
				repaint();
				if(alpha==maxValue){
					shouldAddSelf=false;
				}else if(alpha==minValue){
					shouldAddSelf=true;
				}
				
				if(shouldAddSelf){
					alpha++;
				}else{
					alpha--;
				}
				
				numberColor=Main.lanucher.style.getForegroundByAlpha(alpha);
				
			}
			
		});
		colorTimer.setRepeats(true);
		colorTimer.start();
		//������Panel
		mainPanel=new MainPanel(0,0,130,130);
		mainPanel.setColor(getForeground());
		mainPanel.setSegment(true, true, false, false);
		LinerLayout mainLL = new LinerLayout(200,200,LinerLayout.UP_TO_DOWN,10,0);
		mainLL.add(mainPanel);
		//���ø���Canvas
		watchUpdater = new WatchUpdater(WatchUpdater.WATCH,Main.lanucher.getVersion());
		watchUpdater.setOpaque(false);
		watchUpdater.setForeground(numberColor);
		watchUpdater.setBackground(getBackground());
		watchUpdater.setBounds(mainPanel.getX(), mainPanel.getY(), mainPanel.getWidth(), mainPanel.getHeight());
		Thread updateThread = new Thread() {
			@Override
			public void run() {

				boolean isDifferent = watchUpdater.update();
				if(isDifferent) {
					File file = new File("WatchUpdater.jar");
					Jar jar = new Jar(file);
					jar.run(true, Main.lanucher.getVersion().getVersion());
					System.exit(0);
				}
				
			}
		};
		updateThread.start();
		//������������
		MouseInputListener mil = new MouseInputListener() {
			boolean shouldDrag;
			int px,py;
			int x;
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				requestFocusInWindow();
				
				px=e.getX();
				py=e.getY();
				
				x = e.getX()-mainPanel.getDeltaX();
				
				if(e.getButton()==MouseEvent.BUTTON3) {
					if(!updateThread.isAlive()) {
						shouldShowUpdater=false;
					}
				}
				
				int y = e.getY();
				if( y>mainPanel.getY() && y<(mainPanel.getHeight()+mainPanel.getY()) ) {
					if(e.getButton()==MouseEvent.BUTTON1) {
						shouldDrag=true;
					}else {
						shouldDrag=false;
					}
				}else {
					shouldDrag=true;
					Main.lanucher.frameDragMil.mousePressed(e);
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				//mainPanel.setDelta(mainPanel.getDeltaX()-(mainPanel.getDeltaX())%130, 0);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				if(shouldDrag) {
					Main.lanucher.frameDrag(e, px, py);
				}else {
					mainPanel.setDelta(e.getX()-x, 0);
					System.out.println();
				}
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		};
		this.addMouseListener(mil);
		this.addMouseMotionListener(mil);
		//���ü��̼�����
		this.addKeyListener(new KeyListener() {
			private int mode;
			
			@Override
			public void keyTyped(KeyEvent e) {
				
			}

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.isControlDown()) {
					if(e.getKeyCode()==KeyEvent.VK_C) {
						Clipboard clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
						String str = mainPanel.timePanel.toString();
						StringSelection selection = new StringSelection(str);
						clipBoard.setContents(selection, null);
					}
				}
				switch(e.getKeyCode()) {
					case KeyEvent.VK_Q:
						int gmode = mainPanel.timePanel.getMode();
						if(gmode!=TimePanel.TIME_MODE) {
							mode=gmode;
						}
						mainPanel.timePanel.setMode(TimePanel.TIME_MODE);
						break;
					case KeyEvent.VK_E:
						mainPanel.timePanel.setMode(TimePanel.TIMING_MODE);
						break;
					case KeyEvent.VK_R:
						if(mainPanel.timePanel.isTiming()) {
							mainPanel.timePanel.stopTiming();
						}else if(mainPanel.timePanel.isEnding()){
							mainPanel.timePanel.clearTiming();
						}else {
							mainPanel.timePanel.startTiming();
						}
						break;
					case KeyEvent.VK_W:
						mainPanel.timePanel.lowerPage();
						break;
					case KeyEvent.VK_S:
						mainPanel.timePanel.upperPage();
						break;
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				switch(e.getKeyCode()) {
				case KeyEvent.VK_Q:
					mainPanel.timePanel.setMode(mode);
					break;
				
			}
			}
			
		});
		//Ϊ�˵���ť�ͱ߽�����ʼ��
		int lineWidth = Main.lanucher.style.lineWidth;
		int width = getWidth();
		int height = getHeight();
		int border = Main.lanucher.style.mainBorder;
		//�߽�
		int[] args = {border};
		shape = new MPShape(width, height, args, lineWidth);
		//�밴ť��صĳ�ʼ��
		int lrWidth=Main.lanucher.style.mainButtonBorder,lrHeight=90;
		int udWidth=47,udHeight=Main.lanucher.style.mainButtonBorder;
		//�˵���ť
		int[] mbBorders={lineWidth,lrWidth,lrWidth,lineWidth};
		MPShape mbShape = new MPShape(lrWidth,lrHeight,mbBorders,lineWidth);
		MPButton mBtn=new MPButton(mbShape);
		mBtn.setForeground(Main.lanucher.style.foreground);
		mBtn.setBackground(Main.lanucher.style.foreground.darker());
		//mBtn.setBounds(-btnDelta, border);
		mBtn.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getButton()==MouseEvent.BUTTON1) {
					Main.lanucher.menuCanvas.moveMenu();
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}
			
		});
		this.add(mBtn);
		//��С����ť
		int[] minBorders={lrWidth,lineWidth,lineWidth,lrWidth};
		MPShape minShape = new MPShape(lrWidth,lrHeight,minBorders,lineWidth);
		MPButton minBtn = new MPButton(minShape);
		minBtn.setForeground(Main.lanucher.style.foreground);
		minBtn.setBackground(Main.lanucher.style.foreground.darker());
		//minBtn.setBounds(width-lrWidth+btnDelta, border);
		this.add(minBtn);
		//�ϲ�������ť
		int[] upLeftBorders={lineWidth,lineWidth,lineWidth,udHeight};
		int[] upRightBorders={lineWidth,lineWidth,udHeight,lineWidth};
		MPShape upLeftShape = new MPShape(udWidth,udHeight,upLeftBorders,lineWidth);
		MPShape upRightShape = new MPShape(udWidth,udHeight,upRightBorders,lineWidth);
		MPButton upLeftBtn = new MPButton(upLeftShape);
		MPButton upRightBtn = new MPButton(upRightShape);
		upLeftBtn.setForeground(Main.lanucher.style.foreground);
		upLeftBtn.setBackground(Main.lanucher.style.foreground.darker());
		//upLeftBtn.setBounds(border, -btnDelta);
		upRightBtn.setForeground(Main.lanucher.style.foreground);
		upRightBtn.setBackground(Main.lanucher.style.foreground.darker());
		//upRightBtn.setBounds(width-border-udWidth, -btnDelta);
		upRightBtn.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getButton()==MouseEvent.BUTTON1) {
					Main.lanucher.options.saveToLocal();
					System.exit(0);
				}
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		//����ť������MainCanvas��
		this.add(upLeftBtn);
		this.add(upRightBtn);
		//�²�������ť
		int[] downLeftBorders={udHeight,lineWidth,lineWidth,lineWidth};
		int[] downRightBorders={lineWidth,udHeight,lineWidth,lineWidth};
		MPShape downLeftShape = new MPShape(udWidth,udHeight,downLeftBorders,lineWidth);
		MPShape downRightShape = new MPShape(udWidth,udHeight,downRightBorders,lineWidth);
		MPButton downLeftBtn = new MPButton(downLeftShape);
		MPButton downRightBtn = new MPButton(downRightShape);
		downLeftBtn.setForeground(Main.lanucher.style.foreground);
		downLeftBtn.setBackground(Main.lanucher.style.foreground.darker());
		downRightBtn.setForeground(Main.lanucher.style.foreground);
		downRightBtn.setBackground(Main.lanucher.style.foreground.darker());
		this.add(downLeftBtn);
		this.add(downRightBtn);
		//��ʼʱ��ť�Ķ���
		btnAni =  new Animation(16,Main.lanucher.style.mainButtonBorder,false);
		btnAni.setAction(new ActionListener() {
			private int btnDelta=Main.lanucher.style.mainButtonBorder;
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnDelta--;
				mBtn.setBounds(-btnDelta, border);
				minBtn.setBounds(width-lrWidth+btnDelta, border);
				upLeftBtn.setBounds(border, -btnDelta);
				upRightBtn.setBounds(width-border-udWidth, -btnDelta);
				downLeftBtn.setBounds(border, height-udHeight+btnDelta);
				downRightBtn.setBounds(width-border-udWidth, height-udHeight+btnDelta);
			}
			
		});
		//��ʼʱWatchչ���Ķ���
		spreadAni = new Animation(1,getHeight(),false);
		spreadAni.setAction(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				clipHeight = (int)e.getSource();
			}
			
		});
		Animation.playIndex(spreadAni, btnAni);
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		//����g2d
		g.setClip(0, 0, getWidth(), clipHeight);
		Graphics2D g2d = shape.createGraphics2D(g);
		
		Color shapeColor = getForeground();
		if(!this.isFocusOwner()) {
			shapeColor=Main.lanucher.style.getDarkerForeground();
		}
		shape.paint(g2d, shapeColor, getBackground());
		
		g2d.setColor(getForeground());
		//g2d.setXORMode(new Color(0,255,0));
		
		if(shouldShowUpdater) {
			this.add(watchUpdater);
			watchUpdater.setForeground(numberColor);
		}else {
			this.remove(watchUpdater);
			mainPanel.setForeground(numberColor);
			mainPanel.paint(g);
		}
		
	}

	@Override
	public void paint(Graphics g) {
		BufferedImage img = new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_4BYTE_ABGR);
		
		super.paint(img.createGraphics());
		
		g.drawImage(img, 0, 0, null);
	}
	
}
