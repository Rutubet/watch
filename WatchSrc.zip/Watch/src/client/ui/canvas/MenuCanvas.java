package client.ui.canvas;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

import client.Icons;
import client.Main;
import liren.cap.animation.Animation;
import liren.mp.component.MPButton;
import liren.mp.style.MPShape;

@SuppressWarnings("serial")
public class MenuCanvas extends JPanel{
	private MPShape shape;
	private Animation openMenuAni;
	private Animation closeMenuAni;
	
	private final int SPEED = 6; 
	
	public MenuCanvas(){
		super();
		this.enableInputMethods(false);
		this.setLayout(new FlowLayout(FlowLayout.RIGHT,0-22,13));
		this.setBackground(Main.lanucher.style.background);
		this.setForeground(Main.lanucher.style.foreground);
		this.setBounds(300, 0, 300, 90);
		int border = Main.lanucher.style.menuBorder;
		int width = getWidth();
		int height = getHeight();
		int lineWidth = Main.lanucher.style.lineWidth;
		
		this.shape = new MPShape(width+20,height,new int[] {border,0,0,border},lineWidth);
		
		MPShape btnShape = new MPShape(64,64,new int[] {5},lineWidth);
		
		MPButton optionsBtn = new MPButton(btnShape);
		optionsBtn.setBounds(0, 0, 64, 64);
		optionsBtn.setForeground(Main.lanucher.style.foreground);
		optionsBtn.setBackground(Main.lanucher.style.background);
		optionsBtn.setSize(64, 64);
		optionsBtn.setIcon(Icons.getOptionsIcon(optionsBtn));
		optionsBtn.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				Main.lanucher.optionsFrame.setVisible(true);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		
		MPButton functionBtn = new MPButton(btnShape);
		functionBtn.setBounds(0, 0, 64, 64);
		functionBtn.setForeground(Main.lanucher.style.foreground);
		functionBtn.setBackground(Main.lanucher.style.background);
		functionBtn.setSize(64, 64);
		functionBtn.setIcon(Icons.getFunctionIcon(functionBtn));
		
		this.add(functionBtn);
		this.add(optionsBtn);
		
		openMenuAni=new Animation(10,300/SPEED,false);
		openMenuAni.setAction(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				MenuCanvas.this.setLocation(getX()-SPEED, getY());
				MenuCanvas.this.repaint();
			}
			
		});
		closeMenuAni=new Animation(10,300/SPEED,false);
		closeMenuAni.setAction(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				MenuCanvas.this.setLocation(getX()+SPEED, getY());
				MenuCanvas.this.repaint();
			}
			
		});
		
	}
	
	public void moveMenu(){
		if(getX()==getWidth()){
			openMenu();
		}else if(getX()==0){
			closeMenu();
		}
	}
	
	public void openMenu(){
		openMenuAni.play();
	}
	
	public void closeMenu(){
		closeMenuAni.play();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		shape.paint(g, getForeground(), getBackground());
		
	}
	
}
