package client.ui.canvas;

import java.awt.Graphics;

import javax.swing.JPanel;

import client.Main;

@SuppressWarnings("serial")
public class MenuCanvasContainer extends JPanel{
	public MenuCanvasContainer() {
		this.setOpaque(false);
		this.setLayout(null);
		this.setBounds(0, Main.lanucher.style.mainBorder, 300, 90);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		
	}
	
}
