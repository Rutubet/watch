package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.MouseInputListener;

import client.ui.canvas.MainCanvas;
import client.ui.canvas.MenuCanvas;
import client.ui.canvas.MenuCanvasContainer;
import updater.Version;

public class Lanucher implements Runnable{
	public Style style;
	public Options options;
	
	public JFrame frame;
	public MainCanvas canvas;
	public MenuCanvas menuCanvas;
	public MenuCanvasContainer menuCanvasContainer;
	
	public JFrame optionsFrame;
	public JCheckBox isAlwaysOnTopCheckBox,is24HourClockCheckBox,isPaintNTBackgroundCheckBox;
	public JButton defaultOptionBtn,saveAndExitBtn,saveBtn,exitBtn;
	
	public MouseInputListener frameDragMil;
	
	protected Version version;
	
	public Lanucher(Version version) {
		this.version=version;
		style=new Style();
		
		
	}
	
	private void init() {
		frame = new JFrame();
		canvas = new MainCanvas();
		menuCanvas = new MenuCanvas();
		menuCanvasContainer = new MenuCanvasContainer();
		
		optionsFrame = new JFrame();
		
		isAlwaysOnTopCheckBox = new JCheckBox("������ǰ");
		is24HourClockCheckBox = new JCheckBox("��ʮ��Сʱ��");
		isPaintNTBackgroundCheckBox = new JCheckBox("�������ֵ�ɫ");
		
		defaultOptionBtn = new JButton("�ָ�Ĭ������");
		saveAndExitBtn = new JButton("���沢�˳�");
		saveBtn = new JButton("����");
		exitBtn = new JButton("�˳�");
		
		if(!Options.loadByLocal()) {
			options=new Options();
		}
	}
	
	public Version getVersion() {
		return version;
	}
	
	public void lanuch() {
		init();
		EventQueue.invokeLater(this);
	}

	@Override
	public void run() {
		frame.setBounds(0, 0, 500, 200);
		frame.setLocation(options.frameX, options.frameY);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setBackground(new Color(0,0,0,0));
		
		Container c = frame.getContentPane();
		c.setLayout(null);
		
		canvas.setBackground(style.background);
		canvas.setOpaque(false);
		canvas.setLayout(null);
		c.add(canvas);
		
		c.add(menuCanvasContainer);
		menuCanvas.setOpaque(false);
		menuCanvasContainer.add(menuCanvas);
		
		frameDragMil = new MouseInputListener(){
			int x;
			int y;
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				x=e.getX();
				y=e.getY();
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				frameDrag(e, x, y);
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO �Զ����ɵķ������
				
			}
			
		};
		
		frame.addMouseListener(frameDragMil);
		frame.addMouseMotionListener(frameDragMil);
		
		frame.setVisible(true);
		
		optionsFrame.setTitle("����");
		optionsFrame.setBounds(0, 0, 800, 600);
		optionsFrame.setLocationRelativeTo(null);
		optionsFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		optionsFrame.setLayout(new BorderLayout());
		
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		optionsFrame.add(panel,BorderLayout.CENTER);
		optionsFrame.add(btnPanel,BorderLayout.SOUTH);
		
		panel.add(isAlwaysOnTopCheckBox);
		panel.add(is24HourClockCheckBox);
		panel.add(isPaintNTBackgroundCheckBox);
		
		defaultOptionBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int option = JOptionPane.showConfirmDialog(optionsFrame.getContentPane(), "�Ƿ�Ҫ�ָ�Ĭ������?","",JOptionPane.YES_NO_OPTION,JOptionPane.PLAIN_MESSAGE);
				if(option == JOptionPane.YES_OPTION) {
					Main.lanucher.options = new Options();
					updateOptions();
				}
			}
			
		});
		btnPanel.add(defaultOptionBtn);
		
		saveAndExitBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setOptions();
				options.saveToLocal();
				optionsFrame.setVisible(false);
			}
			
		});
		btnPanel.add(saveAndExitBtn);
		
		saveBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setOptions();
				options.saveToLocal();
			}
			
		});
		btnPanel.add(saveBtn);
		
		exitBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				optionsFrame.setVisible(false);
			}
			
		});
		btnPanel.add(exitBtn);
		
		updateOptions();
	}
	
	public void frameDrag(MouseEvent e,int x,int y) {
		int delta=10;
		int lx=frame.getX()+e.getX()-x;
		int ly=frame.getY()+e.getY()-y;
		int width = Toolkit.getDefaultToolkit().getScreenSize().width;
		int height = Toolkit.getDefaultToolkit().getScreenSize().height;
		if(lx>0 && lx<delta) {
			lx=0;
		}
		if(lx>width-500-delta && lx<width-500) {
			lx=width-500;
		}
		if(ly>0 && ly<delta) {
			ly=0;
		}
		if(ly>height-320-delta && ly<height-320) {
			ly=height-320;
		}
		frame.setLocation(lx, ly);
	}
	
	public void setOptions() {
		options.setIsAlwaysOnTop(isAlwaysOnTopCheckBox.isSelected());
		options.is24HourClock=is24HourClockCheckBox.isSelected();
		options.isPaintNTBackground=isPaintNTBackgroundCheckBox.isSelected();
	}
	
	public void updateOptions() {
		isAlwaysOnTopCheckBox.setSelected(options.getIsAlwayOnTop());
		is24HourClockCheckBox.setSelected(options.is24HourClock);
		isPaintNTBackgroundCheckBox.setSelected(options.isPaintNTBackground);
	}
	
}
