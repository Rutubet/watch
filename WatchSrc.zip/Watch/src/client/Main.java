package client;

import updater.Version;

public class Main  {
	public static Lanucher lanucher;
	
	public static void main(String[] args) {
		Version version=new Version("0.0.2");
		lanucher = new Lanucher(version);
		lanucher.lanuch();
	}
	
}