package client;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class Style {
	public int mainBorder,menuBorder,countDownBorder,lineWidth,mainButtonBorder;
	public Color foreground,background;
	
	public Style(){
		mainBorder=55;
		mainButtonBorder=20;
		menuBorder=15;
		countDownBorder=15;
		lineWidth=1;
		foreground=new Color(77,210,255);
		//foreground=new Color(0,255,0);
		background=new Color(0,0,0,150);
	}
	
	public Graphics2D getG2D(Graphics g){
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setStroke(new BasicStroke(lineWidth*2));
		return g2d;
	}
	
	public Color getForegroundByAlpha(int alpha){
		return new Color(foreground.getRed(),foreground.getGreen(),foreground.getBlue(),alpha);
	}
	
	public Color getDarkerForeground() {
		return getForegroundByAlpha(100);
	}
	
}
